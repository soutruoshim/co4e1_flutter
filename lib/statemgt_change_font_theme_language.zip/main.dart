import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'state_module/logics/language_logic.dart';
import 'state_module/logics/size_logic.dart';
import 'state_module/logics/theme_logic.dart';
import 'state_module/pages/state_page.dart';

void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => SizeLogic()),
        ChangeNotifierProvider(create: (context) => ThemeLogic()),
        ChangeNotifierProvider(create: (context) => LanguageLogic()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: StatePage(),
      ),
    );
  }
}