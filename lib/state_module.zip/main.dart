import 'package:c4e1/state_module/pages/state_app.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(StateApp());
}