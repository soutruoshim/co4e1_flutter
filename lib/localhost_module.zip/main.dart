import 'package:c4e1/localhost_module/pages/article_app.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(ArticleApp());
}